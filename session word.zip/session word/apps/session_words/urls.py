from django.conf.urls import url
from . import views 
urlpatterns=[
    url(r'^$', views.index),#url root
    url(r'^process$',views.process),#url process
    url(r'^clear$',views.clear)#url clear
]